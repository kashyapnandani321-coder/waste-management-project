import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Camera, Upload, Award, Leaf, Recycle, Trash2, X, Play, StopCircle, 
  Shield, Clock, Users 
} from 'lucide-react';

interface ScanResult {
  category: 'organic' | 'recyclable' | 'landfill';
  confidence: number;
  message: string;
  binLabel: string;
}

interface LeaderboardEntry {
  rank: number;
  name: string;
  points: number;
  accuracy: number;
  scans: number;
}

const NeuralBin: React.FC = () => {
  const [isScanning, setIsScanning] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showEncrypted, setShowEncrypted] = useState(false);
  const [encryptedData, setEncryptedData] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'scanner' | 'upload'>('scanner');
  const [uploadPreview, setUploadPreview] = useState<string | null>(null);
  const [uploadFileName, setUploadFileName] = useState('');
  const [isAnalyzingUpload, setIsAnalyzingUpload] = useState(false);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [scanCount, setScanCount] = useState(0);
  const [scanTimestamps, setScanTimestamps] = useState<number[]>([]);
  const [personalScans, setPersonalScans] = useState(0);
  const [personalPoints, setPersonalPoints] = useState(0);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isCameraLoading, setIsCameraLoading] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const MAX_SCANS_PER_MINUTE = 10;
  const RATE_WINDOW_MS = 60000;

  // Fake leaderboard data
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([
    { rank: 1, name: "EcoWarrior92", points: 1240, accuracy: 96, scans: 87 },
    { rank: 2, name: "GreenSortPro", points: 1085, accuracy: 94, scans: 72 },
    { rank: 3, name: "BinNinjaX", points: 975, accuracy: 91, scans: 65 },
    { rank: 4, name: "LeafGuardian", points: 860, accuracy: 93, scans: 58 },
    { rank: 5, name: "RecycleRanger", points: 740, accuracy: 89, scans: 51 },
  ]);

  const categories = {
    organic: {
      label: "Organic Bin",
      color: "bg-emerald-500",
      textColor: "text-emerald-700",
      icon: Leaf,
      message: "Compostable waste detected — perfect for the green bin!",
    },
    recyclable: {
      label: "Recyclable Bin",
      color: "bg-blue-500",
      textColor: "text-blue-700",
      icon: Recycle,
      message: "Materials suitable for recycling — blue bin recommended.",
    },
    landfill: {
      label: "Landfill Bin",
      color: "bg-red-500",
      textColor: "text-red-700",
      icon: Trash2,
      message: "Non-recyclable waste — please use the landfill bin.",
    },
  };

  // Rate limiting logic
  const checkRateLimit = (): boolean => {
    const now = Date.now();
    const recentScans = scanTimestamps.filter(ts => now - ts < RATE_WINDOW_MS);
    return recentScans.length < MAX_SCANS_PER_MINUTE;
  };

  const updateRateLimit = () => {
    const now = Date.now();
    const recent = scanTimestamps.filter(ts => now - ts < RATE_WINDOW_MS);
    setScanTimestamps([...recent, now]);
  };

  const getRemainingScans = () => {
    const now = Date.now();
    const recent = scanTimestamps.filter(ts => now - ts < RATE_WINDOW_MS);
    return Math.max(0, MAX_SCANS_PER_MINUTE - recent.length);
  };

  // AES-256 Encryption using Web Crypto API (Client-side)
  const encryptWithAES = async (data: string): Promise<string> => {
    try {
      const encoder = new TextEncoder();
      const password = import.meta.env.VITE_ENCRYPTION_KEY || "neuralbin-default-secure-key-32char-long-passphrase";
      
      // Derive key using PBKDF2
      const salt = crypto.getRandomValues(new Uint8Array(16));
      const iv = crypto.getRandomValues(new Uint8Array(12));
      
      const keyMaterial = await crypto.subtle.importKey(
        "raw",
        encoder.encode(password),
        { name: "PBKDF2" },
        false,
        ["deriveBits", "deriveKey"]
      );

      const key = await crypto.subtle.deriveKey(
        {
          name: "PBKDF2",
          salt: salt,
          iterations: 100000,
          hash: "SHA-256",
        },
        keyMaterial,
        { name: "AES-GCM", length: 256 },
        false,
        ["encrypt"]
      );

      const encryptedBuffer = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: iv },
        key,
        encoder.encode(data)
      );

      // Combine salt + iv + ciphertext
      const combined = new Uint8Array(
        salt.length + iv.length + encryptedBuffer.byteLength
      );
      combined.set(salt, 0);
      combined.set(iv, salt.length);
      combined.set(new Uint8Array(encryptedBuffer), salt.length + iv.length);

      // Base64 encode
      return btoa(String.fromCharCode(...combined));
    } catch (error) {
      console.error("Encryption failed:", error);
      return "ENCRYPTION_ERROR_SIMULATED_" + Date.now();
    }
  };

  // Strict input sanitization
  const sanitizeInput = (input: string): string => {
    return input
      .replace(/<[^>]*>/g, '') // Remove HTML tags
      .replace(/javascript:/gi, '')
      .replace(/on\w+=/gi, '')
      .trim()
      .slice(0, 200); // Limit length
  };

  // Simulate AI waste detection
  const simulateDetection = async (imageSrc: string): Promise<ScanResult> => {
    // Simulate network delay + processing
    await new Promise(resolve => setTimeout(resolve, 850));

    // Deterministic simulation based on timestamp (for demo repeatability)
    const hash = Date.now() % 3;
    let category: 'organic' | 'recyclable' | 'landfill';
    let confidence = Math.floor(Math.random() * 18) + 78; // 78-95%

    if (hash === 0) {
      category = 'organic';
    } else if (hash === 1) {
      category = 'recyclable';
    } else {
      category = 'landfill';
    }

    const catInfo = categories[category];
    
    return {
      category,
      confidence,
      message: catInfo.message,
      binLabel: catInfo.label,
    };
  };

  // Start webcam
  const startCamera = async () => {
    setCameraError(null);
    setIsCameraLoading(true);
    
    try {
      if (stream) {
        stopCamera();
      }
      
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: "environment",
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });
      
      setStream(mediaStream);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        // Force play with fallback
        const playPromise = videoRef.current.play();
        if (playPromise !== undefined) {
          await playPromise;
        }
      }
      
      setIsScanning(true);
      setScanResult(null);
      setCapturedImage(null);
      setCameraError(null);
    } catch (error: any) {
      console.error("Camera access error:", error);
      let message = "Camera access denied. ";
      if (error.name === 'NotAllowedError') {
        message += "Please allow camera permission in your browser.";
      } else if (error.name === 'NotFoundError') {
        message += "No camera found on this device.";
      } else {
        message += "Please check your camera connection and try again.";
      }
      setCameraError(message);
    } finally {
      setIsCameraLoading(false);
    }
  };

  // Stop webcam
  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsScanning(false);
  };

  // Capture from webcam
  const captureImage = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    const imageDataUrl = canvas.toDataURL('image/jpeg', 0.92);
    setCapturedImage(imageDataUrl);

    // Check rate limit
    if (!checkRateLimit()) {
      alert(`Rate limit reached! You can perform ${MAX_SCANS_PER_MINUTE} scans per minute. Please wait a moment.`);
      return;
    }

    setIsProcessing(true);
    
    try {
      const result = await simulateDetection(imageDataUrl);
      setScanResult(result);
      
      // Update rate limit
      updateRateLimit();
      
      // Award points
      const pointsEarned = Math.floor(result.confidence / 3);
      setPersonalPoints(prev => prev + pointsEarned);
      setPersonalScans(prev => prev + 1);
      setScanCount(prev => prev + 1);

      // Auto stop camera
      stopCamera();

      // Occasionally update leaderboard
      if (Math.random() > 0.6 && personalScans > 3) {
        const newEntry: LeaderboardEntry = {
          rank: leaderboard.length + 1,
          name: "You (Demo)",
          points: personalPoints + pointsEarned,
          accuracy: Math.floor((personalScans * 89 + result.confidence) / (personalScans + 1)),
          scans: personalScans + 1,
        };
        setLeaderboard(prev => [newEntry, ...prev.slice(0, 4)]);
      }
    } catch (error) {
      console.error("Detection failed:", error);
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle photo upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Sanitize filename
    const safeName = sanitizeInput(file.name);
    setUploadFileName(safeName);

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      setUploadPreview(result);
      setScanResult(null);
    };
    reader.readAsDataURL(file);
  };

  const analyzeUpload = async () => {
    if (!uploadPreview) return;

    // Rate limit check
    if (!checkRateLimit()) {
      alert(`Rate limit reached! ${MAX_SCANS_PER_MINUTE} scans per minute allowed.`);
      return;
    }

    setIsAnalyzingUpload(true);

    try {
      const result = await simulateDetection(uploadPreview);
      setScanResult(result);
      
      updateRateLimit();
      
      const pointsEarned = Math.floor(result.confidence / 3);
      setPersonalPoints(prev => prev + pointsEarned);
      setPersonalScans(prev => prev + 1);
      setScanCount(prev => prev + 1);

      // Reset upload state
      setTimeout(() => {
        setUploadPreview(null);
        setUploadFileName('');
        if (fileInputRef.current) fileInputRef.current.value = '';
      }, 1200);
    } catch (error) {
      console.error(error);
    } finally {
      setIsAnalyzingUpload(false);
    }
  };

  // Trigger secure upload simulation
  const handleSecureUpload = async () => {
    if (!capturedImage && !uploadPreview) return;

    const imageToEncrypt = capturedImage || uploadPreview || '';
    
    setShowEncrypted(true);
    const cipherText = await encryptWithAES(
      `IMAGE_DATA:${imageToEncrypt.substring(0, 120)}...|CATEGORY:${scanResult?.category}|CONF:${scanResult?.confidence}`
    );
    setEncryptedData(cipherText);

    // Simulate backend stub
    console.log("🚀 SECURE UPLOAD TO BACKEND STUB:");
    console.log("Encrypted payload (AES-256-GCM):", cipherText.substring(0, 80) + "...");
    console.log("Headers: X-RateLimit: 10/min | X-HSTS: max-age=31536000");
    console.log("Sanitized & Encrypted Scan Result:", scanResult);

    setTimeout(() => {
      setShowEncrypted(false);
      alert("✅ Securely transmitted to backend with AES-256 encryption.\nRate-limited API call logged.");
    }, 1650);
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);

  const currentCategoryInfo = scanResult ? categories[scanResult.category] : null;

  return (
    <div className="min-h-screen bg-[#f8faf5] text-emerald-950 font-sans overflow-hidden">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-lg border-b border-emerald-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 bg-emerald-600 rounded-2xl flex items-center justify-center">
                <Leaf className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="font-semibold text-3xl tracking-tighter">neural<span className="text-emerald-600">bin</span></div>
                <div className="text-[10px] text-emerald-600 -mt-1">AI WASTE INTELLIGENCE</div>
              </div>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-10 text-sm font-medium">
            <a href="#hero" className="hover:text-emerald-600 transition-colors">Home</a>
            <a href="#how" className="hover:text-emerald-600 transition-colors">How it Works</a>
            <a href="#scanner" className="hover:text-emerald-600 transition-colors">Scanner</a>
            <a href="#impact" className="hover:text-emerald-600 transition-colors">Impact</a>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center bg-emerald-50 rounded-full px-4 py-1 text-xs font-mono text-emerald-700">
              <Clock className="w-3.5 h-3.5 mr-1.5" />
              {getRemainingScans()} SCANS LEFT
            </div>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.985 }}
              onClick={() => setShowLeaderboard(true)}
              className="flex items-center gap-2 px-6 py-2.5 rounded-2xl bg-white border border-emerald-200 hover:bg-emerald-50 text-sm font-medium transition-all active:scale-[0.985]"
            >
              <Award className="w-4 h-4" />
              LEADERBOARD
            </motion.button>

            <div className="w-9 h-9 bg-emerald-100 rounded-2xl flex items-center justify-center cursor-pointer">
              <Users className="w-4 h-4 text-emerald-700" />
            </div>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section id="hero" className="pt-20 min-h-[100dvh] flex items-center relative bg-[#f8faf5]">
        <div className="absolute inset-0 bg-[radial-gradient(#e5e7e0_0.8px,transparent_1px)] bg-[length:4px_4px]"></div>
        
        <div className="max-w-5xl mx-auto px-6 relative z-10 pt-12">
          <div className="grid md:grid-cols-12 gap-16 items-center">
            <div className="md:col-span-7">
              <div className="inline-flex items-center gap-2 px-5 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs tracking-[1px] font-medium mb-6">
                🌍 POWERED BY NEURAL NETWORKS
              </div>
              
              <h1 className="text-7xl md:text-[92px] leading-[0.92] font-semibold tracking-tighter mb-6">
                NEURAL<br />BIN
              </h1>
              
              <p className="max-w-lg text-2xl text-emerald-700/90 mb-10">
                AI-powered waste segregation helper.<br />Sort smarter. Live greener.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <motion.button 
                  onClick={() => {
                    document.getElementById('scanner')?.scrollIntoView({ 
                      behavior: 'smooth',
                      block: 'start'
                    });
                    setActiveTab('scanner');
                  }}
                  whileHover={{ scale: 1.02 }}
                  className="group flex-1 sm:flex-none h-16 rounded-3xl bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center gap-3 text-lg font-medium transition-all"
                >
                  <Camera className="w-6 h-6 group-hover:rotate-12 transition" />
                  START SCANNER
                </motion.button>
                
                <motion.button 
                  onClick={() => {
                    document.getElementById('scanner')?.scrollIntoView({ 
                      behavior: 'smooth' 
                    });
                    setActiveTab('upload');
                  }}
                  whileHover={{ scale: 1.02 }}
                  className="group flex-1 sm:flex-none h-16 rounded-3xl border-2 border-emerald-800/70 hover:bg-white flex items-center justify-center gap-3 text-lg font-medium text-emerald-800 transition-all"
                >
                  <Upload className="w-6 h-6" />
                  UPLOAD PHOTO
                </motion.button>
              </div>
            </div>

            <div className="md:col-span-5 relative">
              <motion.div 
                initial={{ opacity: 0, y: 60 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
                className="relative rounded-[3.5rem] overflow-hidden shadow-2xl border border-white/60"
              >
                <img 
                  src="/images/hero.jpg" 
                  alt="Neural Bin AI System" 
                  className="w-full h-auto object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/70" />
                
                <div className="absolute bottom-8 left-8 right-8 text-white">
                  <div className="flex justify-between items-end">
                    <div>
                      <div className="text-xs tracking-widest opacity-70">LIVE DETECTION</div>
                      <div className="text-4xl font-semibold tracking-tight">98.4% ACCURACY</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs opacity-70">MODEL v4.2</div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center">
          <div className="text-xs tracking-[3px] mb-3 text-emerald-700/60">SCROLL TO BEGIN</div>
          <motion.div animate={{ y: [0, 12, 0] }} transition={{ duration: 2.4, repeat: Infinity }} className="w-px h-12 bg-gradient-to-b from-transparent via-emerald-400 to-transparent" />
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how" className="py-24 border-b border-emerald-100 bg-white">
        <div className="max-w-5xl mx-auto px-6">
          <div className="flex flex-col items-center text-center mb-16">
            <div className="text-emerald-600 mb-4">• STEP BY STEP •</div>
            <h2 className="text-6xl tracking-tighter font-semibold">How Neural Bin Works</h2>
            <p className="mt-4 max-w-md text-lg text-emerald-700">Three seconds to smarter sorting</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Camera className="w-10 h-10" />,
                step: "01",
                title: "Capture or Upload",
                desc: "Point your camera at the waste item or upload a photo from gallery. Works with all devices."
              },
              {
                icon: <Shield className="w-10 h-10" />,
                step: "02",
                title: "Instant AI Analysis",
                desc: "Our fine-tuned convolutional neural net classifies in milliseconds. AES-256 encrypted."
              },
              {
                icon: <Leaf className="w-10 h-10" />,
                step: "03",
                title: "Bin Assignment",
                desc: "Receive clear guidance and confidence score. Log your impact to climb the leaderboard."
              }
            ].map((item, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="group relative bg-white border border-emerald-100 rounded-3xl p-10 hover:border-emerald-300 transition-all hover:-translate-y-1"
              >
                <div className="text-emerald-200 text-[140px] font-mono font-bold absolute -top-8 -right-3 group-hover:text-emerald-100 transition">{item.step}</div>
                
                <div className="text-emerald-600 mb-8">{item.icon}</div>
                <h3 className="text-4xl tracking-tight font-semibold mb-4">{item.title}</h3>
                <p className="text-emerald-600 leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* SCANNER SECTION */}
      <section id="scanner" className="py-24 bg-[#f8faf5]">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-emerald-600 mb-3 tracking-widest text-sm">LIVE DEMO</div>
            <h2 className="text-6xl font-semibold tracking-tighter">Waste Intelligence Scanner</h2>
            <p className="mt-3 text-xl text-emerald-700 max-w-md mx-auto">Single-shot detection. Auto-stop. Encrypted transmission.</p>
          </div>

          <div className="flex justify-center mb-6">
            <div className="inline-flex bg-white rounded-3xl p-1 shadow-sm border border-emerald-100">
              <button 
                onClick={() => setActiveTab('scanner')}
                className={`px-9 py-3 rounded-[22px] text-sm font-medium transition-all flex items-center gap-2.5 ${activeTab === 'scanner' ? 'bg-emerald-700 text-white shadow' : 'hover:bg-white/70'}`}
              >
                <Camera className="w-4 h-4" /> LIVE SCANNER
              </button>
              <button 
                onClick={() => setActiveTab('upload')}
                className={`px-9 py-3 rounded-[22px] text-sm font-medium transition-all flex items-center gap-2.5 ${activeTab === 'upload' ? 'bg-emerald-700 text-white shadow' : 'hover:bg-white/70'}`}
              >
                <Upload className="w-4 h-4" /> UPLOAD PHOTO
              </button>
            </div>
          </div>

          <div className="grid lg:grid-cols-5 gap-8">
            {/* Camera / Upload Area */}
            <div className="lg:col-span-3">
              <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-emerald-100 h-full flex flex-col">
                {activeTab === 'scanner' && (
                  <div className="relative flex-1 bg-black flex items-center justify-center min-h-[460px]">
                    {!isScanning && !scanResult && (
                      <div className="text-center px-8">
                        {cameraError && (
                          <div className="mb-6 p-4 bg-red-950/80 text-red-200 text-sm rounded-2xl border border-red-800">
                            {cameraError}
                            <button 
                              onClick={() => setCameraError(null)} 
                              className="block mx-auto mt-3 underline text-xs"
                            >
                              Dismiss
                            </button>
                          </div>
                        )}
                        
                        <motion.button 
                          onClick={startCamera} 
                          disabled={isCameraLoading}
                          className="group mx-auto flex flex-col items-center justify-center w-28 h-28 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 transition-all mb-8 disabled:opacity-70"
                        >
                          {isCameraLoading ? (
                            <div className="w-8 h-8 border-2 border-white border-t-transparent animate-spin rounded-full" />
                          ) : (
                            <Play className="w-12 h-12 text-white group-active:scale-110 transition" />
                          )}
                        </motion.button>
                        
                        <p className="text-white/70 text-sm max-w-[260px]">Tap to start camera.<br />Well-lit environment recommended.</p>
                        <div className="text-[10px] mt-4 text-white/40">Uses rear camera • Requires permission</div>
                      </div>
                    )}

                    {isScanning && (
                      <>
                        <video 
                          ref={videoRef} 
                          className="w-full h-full object-cover" 
                          autoPlay
                          playsInline 
                          muted 
                        />
                        <div className="absolute top-6 right-6 px-4 py-1 bg-black/70 text-white/90 text-xs font-mono tracking-widest rounded">LIVE</div>
                        
                        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-4">
                          <motion.button 
                            onClick={captureImage} 
                            disabled={isProcessing}
                            className="px-8 py-4 bg-white text-black rounded-2xl font-medium flex items-center gap-3 active:scale-95 disabled:opacity-70"
                          >
                            <Camera className="w-5 h-5" />
                            {isProcessing ? "ANALYZING..." : "CAPTURE"}
                          </motion.button>
                          
                          <motion.button 
                            onClick={stopCamera}
                            className="px-8 py-4 bg-white/90 text-black rounded-2xl font-medium flex items-center gap-3 active:scale-95"
                          >
                            <StopCircle className="w-5 h-5" />
                          </motion.button>
                        </div>
                      </>
                    )}

                    {scanResult && capturedImage && (
                      <div className="absolute inset-0 bg-black flex flex-col">
                        <div className="relative flex-1 flex items-center justify-center overflow-hidden bg-zinc-950">
                          <img 
                            src={capturedImage} 
                            alt="Captured waste" 
                            className="w-full h-full object-cover scale-[1.02]" 
                          />
                          
                          {/* Enhanced Result Overlay */}
                          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black/75 flex items-end">
                            <div className="p-9 w-full">
                              <div className="flex items-center justify-between mb-5">
                                <div className={`inline-flex items-center gap-2 px-6 py-1 text-xs font-mono tracking-[1.5px] rounded-full ${currentCategoryInfo?.color} text-white`}>
                                  {currentCategoryInfo && React.createElement(currentCategoryInfo.icon, { className: "w-4 h-4" })}
                                  {scanResult.binLabel.toUpperCase()}
                                </div>
                                <div className="text-xs bg-white/10 px-4 py-1 rounded-full text-white/90 font-mono">CAPTURED IMAGE</div>
                              </div>
                              
                              <div className="text-white text-[72px] font-semibold tracking-[-3.5px] leading-none mb-1">{scanResult.confidence}</div>
                              <div className="-mt-2 text-white/80 text-xl">CONFIDENCE</div>
                              
                              <div className="mt-8 max-w-[420px] text-white/90 text-[15px] leading-tight">
                                {scanResult.message}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    <canvas ref={canvasRef} className="hidden" />
                  </div>
                )}

                {activeTab === 'upload' && (
                  <div className="p-8 flex flex-col flex-1 min-h-[460px]">
                    {!uploadPreview ? (
                      <label 
                        onClick={() => fileInputRef.current?.click()}
                        className="flex-1 border-2 border-dashed border-emerald-200 hover:border-emerald-400 rounded-3xl flex flex-col items-center justify-center cursor-pointer transition-all active:bg-emerald-50/60"
                      >
                        <Upload className="w-12 h-12 text-emerald-400 mb-6" />
                        <div className="text-xl font-medium mb-2">Drop photo here</div>
                        <div className="text-sm text-emerald-600">PNG, JPG up to 8MB</div>
                        <input 
                          ref={fileInputRef}
                          type="file" 
                          accept="image/*" 
                          className="hidden" 
                          onChange={handleFileUpload} 
                        />
                      </label>
                    ) : (
                      <div className="flex flex-col flex-1">
                        <div className="relative flex-1 rounded-3xl overflow-hidden bg-black flex items-center justify-center">
                          <img src={uploadPreview} alt="Preview" className="max-h-[380px] object-contain" />
                        </div>
                        
                        <div className="pt-6 flex gap-3">
                          <button 
                            onClick={analyzeUpload} 
                            disabled={isAnalyzingUpload}
                            className="flex-1 py-4 rounded-2xl bg-emerald-700 text-white font-medium disabled:bg-emerald-300"
                          >
                            {isAnalyzingUpload ? "CLASSIFYING WASTE..." : "ANALYZE PHOTO"}
                          </button>
                          <button 
                            onClick={() => { 
                              setUploadPreview(null); 
                              setUploadFileName(''); 
                              if (fileInputRef.current) fileInputRef.current.value = ''; 
                            }} 
                            className="px-8 py-4 border border-emerald-200 rounded-2xl"
                          >
                            <X />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Results Overlay */}
                <AnimatePresence>
                  {scanResult && (
                    <div className="border-t border-emerald-100 p-8 bg-white">
                      <div className="flex items-start justify-between mb-8">
                        <div>
                          <div className="uppercase tracking-[2px] text-xs text-emerald-500 mb-1">RESULT</div>
                          <div className="text-5xl font-semibold tracking-tight">{scanResult.binLabel}</div>
                        </div>
                        
                        <div className={`px-5 py-2.5 text-sm rounded-2xl text-white flex items-center gap-2 font-medium ${currentCategoryInfo?.color}`}>
                          {currentCategoryInfo && React.createElement(currentCategoryInfo.icon, { className: "w-4 h-4" })} 
                          {scanResult.confidence}%
                        </div>
                      </div>

                      <p className="text-xl leading-tight text-emerald-800 mb-9">{scanResult.message}</p>

                      <div className="flex flex-wrap gap-3">
                        <motion.button 
                          onClick={handleSecureUpload} 
                          className="flex items-center gap-3 px-8 py-4 bg-emerald-800 text-white rounded-2xl hover:bg-black transition-all active:scale-[0.985]"
                        >
                          <Shield className="w-4 h-4" /> SECURE UPLOAD
                        </motion.button>
                        
                        <motion.button 
                          onClick={() => {
                            setScanResult(null);
                            setCapturedImage(null);
                            setUploadPreview(null);
                            setShowEncrypted(false);
                          }} 
                          className="px-8 py-4 border border-emerald-200 rounded-2xl hover:bg-zinc-50 transition"
                        >
                          NEW SCAN
                        </motion.button>
                      </div>
                    </div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* Side Info */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white border border-emerald-100 rounded-3xl p-9">
                <div className="uppercase text-xs tracking-[2px] mb-5 text-emerald-500">CURRENT STREAK</div>
                <div className="text-[92px] font-semibold tracking-[-6px] leading-none text-emerald-950">{personalScans}</div>
                <div className="-mt-3 text-emerald-700 text-xl">successful sorts</div>
                
                <div className="h-px bg-emerald-100 my-8" />
                
                <div className="flex justify-between text-sm mb-2">
                  <div>TOTAL IMPACT POINTS</div>
                  <div className="font-mono text-xl">{personalPoints}</div>
                </div>
                <div className="text-xs text-emerald-500">+{Math.floor(Math.random()*8+4)} this week</div>
              </div>

              <div className="rounded-3xl bg-white p-9 border border-emerald-100 text-sm">
                <div className="flex justify-between mb-8">
                  <div>
                    <div className="text-emerald-600">PRO TIP</div>
                    <div className="font-medium mt-3">For best accuracy:</div>
                  </div>
                  <div className="text-6xl opacity-10">💡</div>
                </div>
                
                <ul className="space-y-6 text-emerald-700">
                  <li className="flex gap-4"><span className="font-mono text-emerald-400">01</span> Place item on neutral background</li>
                  <li className="flex gap-4"><span className="font-mono text-emerald-400">02</span> Ensure good lighting</li>
                  <li className="flex gap-4"><span className="font-mono text-emerald-400">03</span> Hold steady for 2 seconds</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* IMPACT SECTION */}
      <section id="impact" className="py-24 bg-white border-b">
        <div className="max-w-5xl mx-auto px-6">
          <div className="grid md:grid-cols-12 gap-x-6 items-end">
            <div className="md:col-span-5 mb-16 md:mb-0">
              <div className="text-emerald-600 text-sm tracking-widest">OUR COLLECTIVE FOOTPRINT</div>
              <h3 className="text-[68px] leading-none font-semibold tracking-tight mt-4">Real impact,<br />real numbers.</h3>
            </div>
            
            <div className="md:col-span-7 grid grid-cols-2 gap-6">
              {[
                { number: "421k", label: "Items Sorted", suffix: "" },
                { number: "83", label: "Tons of CO₂", suffix: " saved" },
                { number: "4.2m", label: "Liters of Water", suffix: " saved" },
                { number: "19k", label: "Active Users", suffix: "" },
              ].map((stat, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  className="bg-[#f8faf5] border border-emerald-100 px-8 py-14 rounded-3xl"
                >
                  <div className="font-mono text-7xl tracking-tighter font-semibold text-emerald-950">{stat.number}</div>
                  <div className="mt-4 text-xl text-emerald-700">{stat.label}{stat.suffix}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-emerald-950 text-white/80 py-20">
        <div className="max-w-5xl mx-auto px-6 grid md:grid-cols-12 gap-y-16">
          <div className="md:col-span-5">
            <div className="flex items-center gap-3 text-white mb-8">
              <div className="w-9 h-9 bg-white rounded-2xl flex items-center justify-center">
                <Leaf className="text-emerald-950 w-5 h-5" />
              </div>
              <div className="font-semibold text-4xl tracking-tight">neuralbin</div>
            </div>
            
            <div className="max-w-xs text-lg">Helping cities achieve zero waste through intelligent automation.</div>
            
            <div className="mt-8 text-xs opacity-40">© {new Date().getFullYear()} NEURALBIN TECHNOLOGIES LTD.</div>
          </div>

          <div className="md:col-span-3">
            <div className="uppercase text-xs opacity-50 mb-6">PRODUCT</div>
            <div className="space-y-3 text-lg">
              <a href="#" className="block hover:text-white transition">Scanner</a>
              <a href="#" className="block hover:text-white transition">API</a>
              <a href="#" className="block hover:text-white transition">For Cities</a>
            </div>
          </div>
          
          <div className="md:col-span-4">
            <div className="uppercase text-xs opacity-50 mb-6">LEGAL &amp; SECURITY</div>
            
            <div className="text-sm leading-relaxed opacity-60 max-w-xs">
              All client-side data encrypted with AES-256 GCM before upload.<br />Strict rate limiting. HSTS enforced.
            </div>
            
            <div className="mt-8 text-[10px] font-mono opacity-30">VITE_REACT_19 • TAILWIND 4 • FRAMER MOTION</div>
          </div>
        </div>
      </footer>

      {/* LEADERBOARD MODAL */}
      <AnimatePresence>
        {showLeaderboard && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-4" onClick={() => setShowLeaderboard(false)}>
            <motion.div 
              initial={{ opacity: 0, scale: 0.88, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              transition={{ type: "spring", bounce: 0.02, duration: 0.4 }}
              className="bg-white rounded-3xl w-full max-w-lg overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="px-8 pt-9 pb-6 border-b flex items-center justify-between">
                <div>
                  <div className="font-semibold text-4xl tracking-tight">Global Leaderboard</div>
                  <div className="text-sm text-emerald-600">This month • Updated live</div>
                </div>
                <button onClick={() => setShowLeaderboard(false)} className="text-emerald-400 hover:text-black">
                  <X className="w-8 h-8" />
                </button>
              </div>
              
              <div className="divide-y">
                {leaderboard.map((entry, index) => (
                  <div key={index} className="px-8 py-6 flex items-center gap-6">
                    <div className="w-10 text-right font-mono text-4xl text-emerald-200/90 font-semibold">{entry.rank}</div>
                    
                    <div className="flex-1">
                      <div className="font-medium">{entry.name}</div>
                      <div className="text-xs text-emerald-500 flex items-center gap-2">
                        {entry.scans} SCANS • {entry.accuracy}% ACCURACY
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="font-mono text-3xl tracking-tight text-emerald-800">{entry.points}</div>
                      <div className="text-[10px] -mt-1 text-emerald-500">PTS</div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="px-8 py-6 border-t bg-emerald-50 text-xs flex items-center justify-center gap-2 text-emerald-600">
                <Shield className="w-3.5 h-3.5" /> Your scans are private. Compete anonymously.
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ENCRYPTED MODAL */}
      <AnimatePresence>
        {showEncrypted && (
          <div className="fixed inset-0 bg-black/80 z-[200] flex items-center justify-center p-6">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.88, opacity: 0 }}
              className="bg-white rounded-3xl max-w-xl w-full p-10 text-center"
            >
              <Shield className="mx-auto mb-6 text-emerald-600 w-16 h-16" />
              <div className="text-4xl font-semibold tracking-tight mb-4">AES-256 ENCRYPTED</div>
              <p className="text-emerald-700 mb-8">Payload has been encrypted client-side and is ready for secure backend ingestion.</p>
              
              <div className="font-mono text-left text-xs bg-zinc-900 text-emerald-300 p-6 rounded-2xl break-all max-h-52 overflow-auto mb-8">
                {encryptedData}
              </div>
              
              <div className="text-xs text-emerald-500">TRANSMITTED VIA RATE-LIMITED HTTPS ENDPOINT</div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default NeuralBin;

